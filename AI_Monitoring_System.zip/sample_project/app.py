from flask import Flask, render_template, request, jsonify, redirect, url_for
import face_recognition
import numpy as np
import cv2
import base64
import os
import openpyxl
from datetime import datetime
from io import BytesIO
from PIL import Image
import time
import re

app = Flask(__name__)

# Face recognition globals
known_face_encodings = []
known_face_names = []
logged = False
drowsiness_pause_until = 0

# Age and Gender model setup
AGE_LIST = ['(0-2)', '(4-6)', '(8-12)', '(15-20)', '(25-32)', '(38-43)', '(48-53)', '(60-100)']
GENDER_LIST = ['Male', 'Female']
age_net = cv2.dnn.readNetFromCaffe("age_deploy.prototxt", "age_net.caffemodel")
gender_net = cv2.dnn.readNetFromCaffe("gender_deploy.prototxt", "gender_net.caffemodel")
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')

# Drowsiness detection constants
EYE_AR_THRESH = 0.25
EYE_AR_CONSEC_FRAMES = 15
drowsiness_counter = 0
drowsiness_flagged = False

# Question bank with one fill-in-the-blank question (speech-based)
QUESTIONS = [
    {"type": "fill-in-the-blank", "q": "The capital city of France is ____.", "answer": "Paris"},
    {"type": "choice", "q": "What color is the sky?", "options": ["Blue", "Green", "Red", "Yellow"], "answer": "Blue"},
]

def normalize_text(text):
    """Normalize text by removing punctuation, extra spaces, and converting to lowercase."""
    if not text:
        return ""
    # Remove punctuation and convert to lowercase
    text = re.sub(r'[^\w\s]', '', text.lower())
    # Replace multiple spaces with a single space and strip
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def predict_age_gender(face_img_bgr):
    try:
        resized_img = cv2.resize(face_img_bgr, (227, 227))
        blob = cv2.dnn.blobFromImage(resized_img, 1.0, (227, 227),
                                     (78.426, 87.768, 114.895), swapRB=False, crop=False)
        gender_net.setInput(blob)
        gender_preds = gender_net.forward()
        gender = GENDER_LIST[gender_preds[0].argmax()]
        age_net.setInput(blob)
        age_preds = age_net.forward()
        age = AGE_LIST[age_preds[0].argmax()]
        return age, gender
    except Exception as e:
        print(f"Error in predict_age_gender: {e}")
        return "Unknown", "Unknown"

def log_to_excel(username, age, gender):
    file_path = "student_logs.xlsx"
    try:
        if not os.path.exists(file_path):
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            sheet.append(["Name", "Date", "Time", "Age", "Gender"])
            workbook.save(file_path)

        workbook = openpyxl.load_workbook(file_path)
        sheet = workbook.active
        now = datetime.now()
        sheet.append([username, now.strftime("%Y-%m-%d"),
                     now.strftime("%H:%M:%S"), age, gender])
        workbook.save(file_path)
    except Exception as e:
        print(f"Error logging to Excel: {e}")

def eye_aspect_ratio(eye):
    A = np.linalg.norm(eye[1] - eye[5])
    B = np.linalg.norm(eye[2] - eye[4])
    C = np.linalg.norm(eye[0] - eye[3])
    ear = (A + B) / (2.0 * C) if C != 0 else 0
    return ear

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/capture_authorized_face', methods=['POST'])
def capture_authorized_face():
    global known_face_encodings, known_face_names, logged
    try:
        data = request.json
        username = data.get('username', '').strip()
        img_data = data.get('image')

        if not username or not img_data:
            return jsonify({"success": False, "message": "Username or image missing."}), 400

        header, encoded = img_data.split(",", 1)
        img_bytes = base64.b64decode(encoded)
        image = Image.open(BytesIO(img_bytes))
        rgb_img = np.array(image.convert('RGB'))

        os.makedirs('dataset', exist_ok=True)
        save_path = os.path.join('dataset', f"{username}_authorized_face.jpg")
        image.save(save_path)

        encodings = face_recognition.face_encodings(rgb_img)
        if not encodings:
            return jsonify({"success": False, "message": "No face found in the image."}), 400

        known_face_encodings = [encodings[0]]
        known_face_names = [username]
        logged = False
        return jsonify({"success": True, "message": "Authorized face saved."}), 200
    except Exception as e:
        print(f"Error in capture_authorized_face: {e}")
        return jsonify({"success": False, "message": f"Error: {str(e)}"}), 500

@app.route('/recognize_face', methods=['POST'])
def recognize_face():
    global logged, drowsiness_counter, drowsiness_flagged
    try:
        data = request.json
        img_data = data.get('image')

        if not img_data or not known_face_encodings:
            return jsonify({"success": False, "message": "No known face or image provided."}), 400

        header, encoded = img_data.split(",", 1)
        img_bytes = base64.b64decode(encoded)
        image = Image.open(BytesIO(img_bytes))
        rgb_img = np.array(image.convert('RGB'))

        face_locations = face_recognition.face_locations(rgb_img)
        face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

        if face_encodings:
            for face_encoding, face_loc in zip(face_encodings, face_locations):
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                if True in matches:
                    name = known_face_names[matches.index(True)]
                    top, right, bottom, left = face_loc
                    top = max(0, top)
                    right = min(rgb_img.shape[1], right)
                    bottom = min(rgb_img.shape[0], bottom)
                    left = max(0, left)

                    face_img = rgb_img[top:bottom, left:right]
                    face_img_bgr = cv2.cvtColor(face_img, cv2.COLOR_RGB2BGR)
                    age, gender = predict_age_gender(face_img_bgr)

                    gray = cv2.cvtColor(face_img_bgr, cv2.COLOR_BGR2GRAY)
                    eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
                    
                    ear_avg = 0.0
                    if len(eyes) >= 2:
                        eyes = sorted(eyes, key=lambda e: e[2]*e[3], reverse=True)[:2]
                        ears = []
                        for (ex, ey, ew, eh) in eyes:
                            ear = eh / ew
                            ears.append(ear)
                        ear_avg = np.mean(ears)

                    if ear_avg < EYE_AR_THRESH:
                        drowsiness_counter += 1
                    else:
                        drowsiness_counter = 0
                        drowsiness_flagged = False

                    if drowsiness_counter >= EYE_AR_CONSEC_FRAMES:
                        drowsiness_flagged = True

                    if not logged:
                        log_to_excel(name, age, gender)
                        logged = True

                    return jsonify({
                        "success": True,
                        "message": f"Access Granted: Welcome {name} | {gender}, {age}",
                        "name": name,
                        "age": age,
                        "gender": gender,
                        "drowsiness": drowsiness_flagged,
                        "ear": ear_avg
                    }), 200
            return jsonify({"success": False, "message": "Authorization failed!"}), 401
        return jsonify({"success": False, "message": "No face detected."}), 400
    except Exception as e:
        print(f"Error in recognize_face: {e}")
        return jsonify({"success": False, "message": f"Error: {str(e)}"}), 500

@app.route('/exam')
def exam_redirect():
    username = request.args.get('username', '')
    if not username:
        return render_template('error.html', message="Username is required."), 400
    return redirect(url_for('exam_question', qnum=0, score=0, username=username))

@app.route('/exam_question', methods=['GET', 'POST'])
def exam_question():
    try:
        if request.method == 'POST':
            qnum = int(request.form.get('qnum', 0)) - 1
            score = int(request.form.get('score', 0))
            username = request.form.get('username', '')
            
            if qnum < 0 or qnum >= len(QUESTIONS):
                return render_template('error.html', message="Invalid question number."), 400
            if not username:
                return render_template('error.html', message="Username is required."), 400

            # Handle both question types
            response = request.form.get('option', '') if QUESTIONS[qnum]['type'] == 'choice' else request.form.get('answer', '')
            response = normalize_text(response)
            correct = normalize_text(QUESTIONS[qnum]['answer'])

            print(f"Normalized response: '{response}'")
            print(f"Normalized correct: '{correct}'")

            if response == correct:
                score += 1
            qnum += 1
        else:
            qnum = int(request.args.get('qnum', 0))
            score = int(request.args.get('score', 0))
            username = request.args.get('username', '')
            if not username:
                return render_template('error.html', message="Username is required."), 400

        if qnum >= len(QUESTIONS):
            return render_template('exam_result.html',
                                 score=score, total=len(QUESTIONS),
                                 username=username)

        question = QUESTIONS[qnum]
        return render_template('exam_question.html',
                             question=question,
                             qnum=qnum + 1,
                             total=len(QUESTIONS),
                             score=score,
                             username=username)
    except Exception as e:
        print(f"Error in exam_question: {e}")
        return render_template('error.html', message=f"Error: {str(e)}"), 500

@app.route('/exam_status', methods=['POST'])
def exam_status():
    global drowsiness_pause_until
    try:
        data = request.json
        img_data = data.get('image')
        username = data.get('username')
        qnum = int(data.get('qnum', 0))
        score = int(data.get('score', 0))

        if not username:
            return jsonify({"status": "error", "message": "Username is required.", "alert": True}), 400

        now = time.time()
        if now < drowsiness_pause_until:
            seconds_left = int(drowsiness_pause_until - now)
            return jsonify({
                "status": "paused",
                "message": f"Exam paused due to drowsiness. Resuming in {seconds_left} seconds.",
                "pause_seconds_left": seconds_left,
                "alert": True,
                "score": score,
                "qnum": qnum,
                "username": username
            }), 200

        if not img_data or not known_face_encodings:
            return jsonify({
                "status": "dismissed",
                "message": "No authorized face registered or no image provided.",
                "alert": True,
                "score": score,
                "qnum": qnum,
                "username": username
            }), 401

        header, encoded = img_data.split(",", 1)
        img_bytes = base64.b64decode(encoded)
        image = Image.open(BytesIO(img_bytes))
        rgb_img = np.array(image.convert('RGB'))

        face_locations = face_recognition.face_locations(rgb_img)
        face_encodings = face_recognition.face_encodings(rgb_img, face_locations)

        if len(face_encodings) != 1:
            return jsonify({
                "status": "dismissed",
                "message": "No face or multiple faces detected.",
                "alert": True,
                "score": score,
                "qnum": qnum,
                "username": username
            }), 401

        matches = face_recognition.compare_faces(known_face_encodings, face_encodings[0])
        if not matches or not matches[0]:
            return jsonify({
                "status": "dismissed",
                "message": "Unauthorized face detected.",
                "alert": True,
                "score": score,
                "qnum": qnum,
                "username": username
            }), 401

        top, right, bottom, left = face_locations[0]
        top = max(0, top)
        right = min(rgb_img.shape[1], right)
        bottom = min(rgb_img.shape[0], bottom)
        left = max(0, left)

        face_img = rgb_img[top:bottom, left:right]
        face_img_bgr = cv2.cvtColor(face_img, cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(face_img_bgr, cv2.COLOR_BGR2GRAY)
        eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        ear_avg = 0.0
        if len(eyes) >= 2:
            eyes = sorted(eyes, key=lambda e: e[2]*e[3], reverse=True)[:2]
            ears = []
            for (ex, ey, ew, eh) in eyes:
                ear = eh / ew
                ears.append(ear)
            ear_avg = np.mean(ears)

        if ear_avg < EYE_AR_THRESH:
            drowsiness_pause_until = time.time() + 10
            return jsonify({
                "status": "paused",
                "message": "Drowsiness detected! Exam paused for 10 seconds.",
                "pause_seconds_left": 10,
                "alert": True,
                "score": score,
                "qnum": qnum,
                "username": username
            }), 200

        status = "completed" if qnum >= len(QUESTIONS) else "in_progress"
        current_question = None if status == "completed" else {
            "question": QUESTIONS[qnum]['q'],
            "options": QUESTIONS[qnum].get('options', []),
            "qnum": qnum,
            "total": len(QUESTIONS)
        }

        return jsonify({
            "status": status,
            "current_question": current_question,
            "score": score,
            "qnum": qnum,
            "username": username,
            "alert": False
        }), 200
    except Exception as e:
        print(f"Error in exam_status: {e}")
        return jsonify({
            "status": "error",
            "message": f"Error: {str(e)}",
            "alert": True,
            "score": score,
            "qnum": qnum,
            "username": username
        }), 500

if __name__ == "__main__":
    app.run(debug=True)